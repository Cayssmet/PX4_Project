"""使用中文 YAML 参数启动航点管理器。"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    params_file = os.path.join(
        get_package_share_directory("waypoint_manager"),
        "config",
        "waypoint_manager_params.yaml",
    )

    return LaunchDescription(
        [
            Node(
                package="waypoint_manager",
                executable="waypoint_manager_node",
                name="waypoint_manager",
                output="screen",
                parameters=[params_file],
            )
        ]
    )
