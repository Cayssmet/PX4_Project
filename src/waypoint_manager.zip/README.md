# waypoint_manager：航线存储、发送与任务推进功能包

## 一、功能包用途

`waypoint_manager` 是运行在树莓派 Ubuntu 24.04 / ROS 2 Jazzy 上的航点管理功能包。

它把原本可能拆开的“航线存储包”和“航点发送包”合并为一个完整功能包，负责：

1. 从中文 YAML 中读取本地调试/备用航线；
2. 接收地面站发送的一整条正式航线；
3. 检查整条新航线，只有全部合法才原子替换旧航线；
4. 按数组顺序选择当前航点；
5. 向 `position_pid_controller` 发送当前航点的 `x、y、yaw`；
6. 向后续飞控通信包发布包含目标高度的完整当前航点；
7. 同时检查平面/yaw 到达反馈和飞控高度到达反馈；
8. 经过到达确认与停留时间后切换到下一航点；
9. 最后一个航点完整完成后发布降落请求。

本包不计算 PID 速度、不读取飞控姿态、不直接打开串口，也不控制电机。

---

## 二、与现有功能包的关系

```text
地面站
  │  整条 WaypointList 航线
  ▼
ground_station_bridge（后续编写）
  │  调用 /waypoint/set_list
  ▼
waypoint_manager（本包）
  ├── /pid/target_pose ───────────────► position_pid_controller
  │                                      │
  │                                      ├── /pid/cmd_vel
  │                                      └── /pid/target_reached
  │
  ├── /waypoint/current ──────────────► flight_controller_bridge（后续编写）
  ├── /mission/land_request ──────────► flight_controller_bridge（后续编写）
  │                                      │
  │                                      └── /flight/status
  ▼
根据“PID 已到达 + 高度已到达”推进航点
```

当前坐标仍由 `map_coordinate_provider` 提供给 PID，本包不重复读取地图坐标。

---

## 三、坐标系和单位

ROS 2 内部航点约定：

- `x、y`：`map` 地图坐标系，单位为米（m）；
- `yaw`：单位为弧度（rad），从上向下看逆时针为正；
- `target_height`：目标离地高度，单位为米（m）；
- `hold_time`：航点到达后的期望停留时间，单位为秒（s）。

凌霄飞控机体系约定是：机头方向为 `x` 正、左侧为 `y` 正、上方为 `z` 正、逆时针为 `yaw` 正。

注意：本包发给 PID 的 `vx/vy` 目标仍属于地图坐标系。后续 `flight_controller_bridge` 必须使用当前地图 yaw，把地图速度旋转到飞控机体系后再通过串口发送。本包不负责该旋转。

---

## 四、默认比赛模式为什么不会执行本地航线

参数文件默认设置为：

```yaml
require_ground_station_route: true
allow_local_route_for_test: false
```

因此节点启动后即使：

- YAML 已写入本地航点；
- `position_pid_controller` 已启动并连接；
- 飞控状态正常；

管理器仍然保持 `WAITING_FOR_ROUTE`，不会发布 `/pid/target_pose`，也不会激活 `/waypoint/current`。只有 `/waypoint/set_list` 收到一条完整且合法的地面站航线后，任务才会开始。

本地 YAML 航线默认只是调试候选和备用数据，不是比赛任务来源。

### 本地无地面站测试

只在台架测试时把两个参数改为：

```yaml
require_ground_station_route: false
allow_local_route_for_test: true
```

此时节点会自动激活 YAML 中的本地航线。

完成测试后务必恢复比赛模式。

---

## 五、到达航点的完整判定

一个航点不是仅凭 `/pid/target_reached=true` 就完成。必须同时满足：

1. `/pid/target_reached=true`，即 x/y/yaw 已进入 PID 容差；
2. `/flight/status.communication_ok=true`；
3. `/flight/status.height_reached=true`，即飞控内部 z 轴 PID 已到达目标高度；
4. `/flight/status.failsafe=false`；
5. 两类反馈都没有超时；
6. 上述条件连续成立 `arrival_confirm_time`；
7. 再完成当前航点的实际停留时间。

默认时间为：

```text
连续到达确认：0.7 s
最小停留时间：1.0 s
正常最短总时间：约 1.7 s
```

实际停留时间使用：

```text
max(minimum_hold_time, 当前航点 hold_time)
```

所以航点填写 `hold_time=0.5` 时，默认仍会停留 1 秒；填写 `hold_time=2.0` 时则停留 2 秒。

### 反馈波动处理

进入停留状态后，如果到达反馈短暂变为 `false`：

- 持续不超过 `reach_lost_grace_time=0.3 s`：视为测量噪声，保留停留进度；
- 持续超过 0.3 s：认为飞行器确实离开目标，清空本次确认和停留，重新跟踪。

建议飞控端的 `height_reached` 也使用迟滞，例如进入误差 0.05 m、退出误差 0.10 m，具体数值必须根据激光高度反馈实测调整。

---

## 六、任务状态

`/mission/status.state` 使用 `uav_interfaces/msg/MissionStatus` 中的常量：

| 状态 | 数值 | 含义 |
|---|---:|---|
| `WAITING_FOR_ROUTE` | 0 | 正在等待地面站合法航线 |
| `WAITING_FOR_PID` | 1 | 航线有效，但 PID 目标订阅者未连接 |
| `TRACKING` | 2 | 正在接近当前航点或执行 0.7 秒到达确认 |
| `DWELLING` | 3 | 已确认到达，正在执行航点停留 |
| `COMPLETED` | 4 | 最后一个航点已经完整完成 |
| `ERROR` | 5 | 飞控报告 failsafe，任务推进暂停 |

飞控 `failsafe` 恢复为 `false` 且反馈重新有效后，管理器可以恢复跟踪；它不会在故障状态下跳到下一个航点。

---

## 七、ROS 2 接口

### 1. 地面站航线服务

```text
/waypoint/set_list
类型：uav_interfaces/srv/SetWaypointList
```

请求包含一整条 `WaypointList`，响应包含：

- `accepted=true`：整条航线已检查通过并生效；
- `accepted=false`：新航线被拒绝，原来的活动航线保持不变；
- `message`：面向操作者的具体原因。

航线执行过程中也可以提交新航线。合法新航线会立即覆盖旧航线，任务回到新航线第 1 个航点，清空旧的确认、停留、完成和降落状态。

### 2. 发给 PID 的当前目标

```text
/pid/target_pose
类型：geometry_msgs/msg/PoseStamped
QoS：reliable + volatile
```

字段：

- `header.frame_id="map"`；
- `position.x/y` 为当前航点地图坐标；
- `orientation` 由当前航点 yaw 生成。

由于现有 PID 每次收到目标都会重置控制状态，本包只在以下情况发送：

- 有效航线激活且 PID 已连接；
- 切换到下一航点；
- 地面站合法航线覆盖旧航线；
- PID 断开后重新连接。

不会周期性重复发送同一个目标。

### 3. 发给飞控桥的完整当前航点

```text
/waypoint/current
类型：uav_interfaces/msg/Waypoint
QoS：reliable + transient_local，保留最后一条
```

其中包含 `x、y、yaw、target_height、hold_time、id`。后续飞控桥主要使用 `target_height`，并可使用 `id` 做日志和帧序号关联。

### 4. PID 到达反馈

```text
/pid/target_reached
类型：std_msgs/msg/Bool
```

只有 x/y/yaw 同时进入 PID 保持区域时才应为 `true`。

### 5. 飞控状态反馈

```text
/flight/status
类型：uav_interfaces/msg/FlightStatus
```

本包实际使用：

- `communication_ok`；
- `height_reached`；
- `failsafe`。

本包不读取飞控姿态。

### 6. 降落请求

```text
/mission/land_request
类型：std_msgs/msg/Bool
QoS：reliable + transient_local
```

最后一个航点完整完成后变为 `true`。降落模式下，后续飞控桥和飞控程序应忽略普通 `target_height`，进入专用降落流程。

`target_height=0` 不代表降落；降落只由 `land_request=true` 表示。

### 7. 任务状态

```text
/mission/status
类型：uav_interfaces/msg/MissionStatus
QoS：reliable + transient_local
```

用于地面站显示、日志记录和后续飞控桥安全门控。

---

## 八、航线检查规则

收到的新航线必须全部满足：

- `header.frame_id` 等于配置中的 `map_frame`，默认 `map`；
- 至少 1 个航点且不超过 `max_waypoints`；
- 每个航点 `id` 唯一；
- x/y/yaw/目标高度/停留时间都是有限数，不允许 NaN 或无穷大；
- `abs(x) <= max_abs_x`；
- `abs(y) <= max_abs_y`；
- 目标高度在配置上下限内；
- `hold_time` 在 0 到 `max_hold_time` 之间；
- yaw 在接收后统一归一化到 `[-pi, pi]`。

任意一个航点非法都会拒绝整条新航线，旧航线不会被改写一半。

---

## 九、放入树莓派工作空间

本项目约定树莓派工作空间为：

```text
/home/ljz/ros2_ws
```

最终目录应为：

```text
/home/ljz/ros2_ws/src/uav_interfaces
/home/ljz/ros2_ws/src/waypoint_manager
/home/ljz/ros2_ws/src/position_pid_controller
/home/ljz/ros2_ws/src/map_coordinate_provider
```

不要形成下面这种多套一层的错误结构：

```text
/home/ljz/ros2_ws/src/waypoint_manager/waypoint_manager/CMakeLists.txt
```

正确结构中，`CMakeLists.txt` 应直接位于：

```text
/home/ljz/ros2_ws/src/waypoint_manager/CMakeLists.txt
```

本次交付的 `waypoint_manager.zip` 内部已经直接以 `CMakeLists.txt、src、config` 等开头，
可在树莓派上这样解压：

```bash
mkdir -p /home/ljz/ros2_ws/src/waypoint_manager
unzip waypoint_manager.zip -d /home/ljz/ros2_ws/src/waypoint_manager
```

然后用上面的正确路径检查 `CMakeLists.txt` 是否存在。

---

## 十、安装依赖并构建

打开终端：

```bash
cd /home/ljz/ros2_ws
source /opt/ros/jazzy/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install --packages-select uav_interfaces waypoint_manager
source /home/ljz/ros2_ws/install/setup.bash
```

因为 `waypoint_manager` 使用 `uav_interfaces` 的自定义消息，首次构建时必须同时存在并先成功生成接口。`colcon` 会按依赖关系自动安排顺序。

每次打开新终端都需要：

```bash
source /opt/ros/jazzy/setup.bash
source /home/ljz/ros2_ws/install/setup.bash
```

检查功能包：

```bash
ros2 pkg list | grep -E "uav_interfaces|waypoint_manager"
```

---

## 十一、正式比赛模式启动

先确认配置仍为：

```yaml
require_ground_station_route: true
allow_local_route_for_test: false
```

启动：

```bash
source /opt/ros/jazzy/setup.bash
source /home/ljz/ros2_ws/install/setup.bash
ros2 launch waypoint_manager waypoint_manager.launch.py
```

此时终端提示正在等待地面站航线是正常现象，不是故障。

查看状态：

```bash
ros2 topic echo /mission/status uav_interfaces/msg/MissionStatus
```

在地面站下发前应看到：

```text
state: 0
route_valid: false
target_sent: false
mission_completed: false
```

---

## 十二、用命令行模拟地面站发送航线

下面命令发送 route_id=1001 的两个航点：

```bash
ros2 service call /waypoint/set_list uav_interfaces/srv/SetWaypointList \
"{waypoint_list: {header: {frame_id: map}, route_id: 1001, waypoints: [
  {id: 1, x: 1.0, y: 0.0, yaw: 0.0, target_height: 1.2, hold_time: 1.0},
  {id: 2, x: 1.0, y: 1.0, yaw: 1.5708, target_height: 1.5, hold_time: 1.0}
]}}"
```

成功响应类似：

```text
accepted: true
message: 已接收 route_id=1001，共 2 个航点
```

错误 frame 示例会被拒绝：

```bash
ros2 service call /waypoint/set_list uav_interfaces/srv/SetWaypointList \
"{waypoint_list: {header: {frame_id: odom}, route_id: 1002, waypoints: [
  {id: 1, x: 0.0, y: 0.0, yaw: 0.0, target_height: 1.0, hold_time: 1.0}
]}}"
```

---

## 十三、暂时没有真实飞控桥时的联调

没有飞控串口包时，可以临时模拟高度已到达：

```bash
ros2 topic pub -r 20 /flight/status uav_interfaces/msg/FlightStatus \
"{communication_ok: true, height_reached: true, land_accepted: false, land_completed: false, failsafe: false}"
```

如果还需要单独模拟 PID 已到达：

```bash
ros2 topic pub -r 20 /pid/target_reached std_msgs/msg/Bool "{data: true}"
```

观察当前航点：

```bash
ros2 topic echo --qos-durability transient_local \
  /waypoint/current uav_interfaces/msg/Waypoint
```

观察最终降落请求：

```bash
ros2 topic echo /mission/land_request std_msgs/msg/Bool
```

这些模拟命令只能用于无桨或安全台架联调，不能代替真机反馈。

---

## 十四、推荐的完整启动顺序

每个终端都先 source 工作空间，然后按以下顺序启动：

1. 雷达驱动、SLAM/建图和 TF；
2. `map_coordinate_provider`；
3. `position_pid_controller`；
4. `waypoint_manager`；
5. 后续 `flight_controller_bridge`；
6. 后续 `ground_station_bridge`，并等待地面站正式航线；
7. 检查所有有效标志后才允许飞控执行速度命令。

航点管理器可以在 PID 之前启动。它会进入 `WAITING_FOR_PID`，检测到 PID 订阅建立后只补发一次当前目标。

---

## 十五、当前必须注意的安全边界

现有 `position_pid_controller` 在没有收到外部目标之前，会使用它自己的 YAML 初始目标，默认是地图原点 `(0, 0, 0)`。航点管理器虽然在地面站航线到达前不会发送目标，但它不能阻止 PID 节点自己计算这个初始目标的速度。

因此在后续 `flight_controller_bridge` 中必须设置安全门：只有同时满足下面条件，才允许把非零速度发给飞控：

```text
/mission/status.route_valid == true
/mission/status.target_sent == true
/pid/control_valid == true
串口与飞控状态正常
```

否则必须给飞控发送无效/零速度命令。未来也建议在 PID 包增加 `require_external_target` 参数作为第二层保护，但本次没有擅自修改已经验证可用的 PID 包。

在飞控桥完成以前，不要把当前 PID 输出直接接到真机执行层。

---

## 十六、自动测试

构建后运行：

```bash
cd /home/ljz/ros2_ws
source /opt/ros/jazzy/setup.bash
colcon test --packages-select waypoint_manager
colcon test-result --verbose
```

测试内容包括：

- 连续 0.7 秒到达确认；
- 1 秒停留；
- 0.3 秒短时反馈丢失宽限；
- 长时间失去到达条件后重新确认；
- 时间倒退保护；
- yaw 归一化；
- 重复航点 id、错误 frame、NaN、越界高度和超长停留拒绝；
- 默认比赛模式不执行本地航线；
- 地面站航线生效后只发送一次 PID 目标；
- 单航点任务完整结束并请求降落；
- 非法覆盖航线被拒绝且旧航线保留。

---

## 十七、常见问题

### 1. 一直显示 WAITING_FOR_ROUTE

默认比赛模式下这是正确行为。需要地面站桥或命令行成功调用 `/waypoint/set_list`。

检查：

```bash
ros2 service list | grep waypoint
ros2 service type /waypoint/set_list
```

### 2. 显示 WAITING_FOR_PID

活动航线已经存在，但没有检测到 `/pid/target_pose` 的订阅者。

检查：

```bash
ros2 topic info /pid/target_pose --verbose
ros2 node list
```

### 3. 一直不切换到下一航点

分别检查：

```bash
ros2 topic echo /pid/target_reached std_msgs/msg/Bool
ros2 topic echo /flight/status uav_interfaces/msg/FlightStatus
ros2 topic echo /mission/status uav_interfaces/msg/MissionStatus
```

常见原因是：PID 未到达、高度未到达、通信标志为 false、failsafe 为 true、反馈频率太低导致超时，或者到达状态没有连续维持 0.7 秒。

### 4. 地面站新航线被拒绝

服务响应的 `message` 会指出具体原因。最常见的是 `frame_id` 不是 `map`、数组为空、航点 id 重复、目标高度超出配置范围或数值包含 NaN。

### 5. 为什么不周期重发 PID 目标

因为当前 `position_pid_controller` 每次收到 `/pid/target_pose` 都会清空三轴 PID 和迟滞保持状态。周期重发会导致它不断重置，无法正常积累和控制。本包通过 DDS 连接检测在首次连接和重连时补发。

### 6. 地面站断开后航线会消失吗

不会。整条航线一旦被服务成功接收，就保存在航点管理器内存中，地面站暂时断开不影响继续执行。但重启树莓派或节点后内存航线会消失，比赛模式会重新等待地面站下发。

### 7. 地面站航线会写回 YAML 吗

不会。运行时航线只保存在内存中，避免意外覆盖人工配置文件。重启后仍使用原 YAML 候选，并在比赛模式等待地面站重新发送。

---

## 十八、后续扩展

如果赛题后续增加航点动作、速度限制或拍照标志，不需要重写整个航点管理器。推荐流程是：

1. 在 `uav_interfaces/msg/Waypoint.msg` 增加语义明确的新字段；
2. 在 `uav_interfaces/CMakeLists.txt` 保持该消息被生成；
3. 重新构建 `uav_interfaces` 和依赖它的包；
4. 在本包的航线检查和当前航点发布处增加对应处理；
5. 在地面站桥或飞控桥中消费新字段。

现有的航线服务、状态机和原子替换机制可以继续使用，不需要推倒重来。

---

## 十九、文件结构

```text
waypoint_manager/
├── CMakeLists.txt
├── package.xml
├── README.md
├── config/
│   └── waypoint_manager_params.yaml
├── include/waypoint_manager/
│   ├── arrival_tracker.hpp
│   └── route_validation.hpp
├── launch/
│   └── waypoint_manager.launch.py
├── src/
│   └── waypoint_manager_node.cpp
└── test/
    ├── test_arrival_tracker.cpp
    ├── test_route_validation.cpp
    └── test_waypoint_manager_launch.py
```

所有关键逻辑、配置项和测试均带有中文注释，方便后续调参与扩展。
