#ifndef SIMPLE_PID_CONTROLLER__SIMPLE_PID_HPP_
#define SIMPLE_PID_CONTROLLER__SIMPLE_PID_HPP_

#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace simple_pid_controller
{

// SimplePid 是一个与 ROS 2 无关的纯 C++ PID 计算类。
// 将数学部分单独放在这个头文件中有两个好处：
// 1. 可以不启动 ROS 2 就单独测试 PID 公式；
// 2. 以后可以在其他控制节点中直接复用，而不必复制公式。
class SimplePid
{
public:
  // kp、ki、kd 分别是比例、积分、微分系数。
  // output_min/output_max 用于限制最终输出，避免指令过大。
  // integral_min/integral_max 用于限制积分累计，减轻积分饱和。
  SimplePid(
    const double kp, const double ki, const double kd,
    const double output_min, const double output_max,
    const double integral_min, const double integral_max)
  : kp_(kp),
    ki_(ki),
    kd_(kd),
    output_min_(output_min),
    output_max_(output_max),
    integral_min_(integral_min),
    integral_max_(integral_max)
  {
    if (!all_finite() || output_min_ > output_max_ || integral_min_ > integral_max_) {
      throw std::invalid_argument("PID parameters or limits are invalid");
    }
  }

  double update(const double setpoint, const double measurement, const double dt)
  {
    // PID 只能处理有限数值，dt 也必须大于零，否则微分项无法计算。
    if (!std::isfinite(setpoint) || !std::isfinite(measurement) ||
      !std::isfinite(dt) || dt <= 0.0)
    {
      throw std::invalid_argument("PID inputs must be finite and dt must be positive");
    }

    // 当前误差：目标值减去当前测量值。
    const double error = setpoint - measurement;

    // 积分项是误差随时间的累计。
    // std::clamp 将积分限制在指定范围内，防止长时间误差导致积分无限增大。
    integral_ = std::clamp(integral_ + error * dt, integral_min_, integral_max_);

    // 第一次计算时没有“上一次误差”，因此微分项先取零。
    // 从第二次开始，用相邻两次误差之差除以时间间隔得到误差变化率。
    double derivative = 0.0;
    if (has_previous_error_) {
      derivative = (error - previous_error_) / dt;
    }

    previous_error_ = error;
    has_previous_error_ = true;

    // 标准 PID 公式：P + I + D。
    const double output = kp_ * error + ki_ * integral_ + kd_ * derivative;

    // 最终结果仍要经过输出限幅。
    return std::clamp(output, output_min_, output_max_);
  }

  // 清空 PID 的历史状态。重新开始一次控制任务时可以调用它。
  void reset()
  {
    integral_ = 0.0;
    previous_error_ = 0.0;
    has_previous_error_ = false;
  }

  double integral() const
  {
    return integral_;
  }

private:
  // 构造时集中检查所有配置值，避免 NaN 或无穷值进入 PID。
  bool all_finite() const
  {
    return std::isfinite(kp_) && std::isfinite(ki_) && std::isfinite(kd_) &&
           std::isfinite(output_min_) && std::isfinite(output_max_) &&
           std::isfinite(integral_min_) && std::isfinite(integral_max_);
  }

  double kp_;                  // 比例系数
  double ki_;                  // 积分系数
  double kd_;                  // 微分系数
  double output_min_;          // PID 输出下限
  double output_max_;          // PID 输出上限
  double integral_min_;        // 积分累计下限
  double integral_max_;        // 积分累计上限
  double integral_{0.0};       // 当前已经累计的误差积分
  double previous_error_{0.0}; // 上一次误差，用来计算微分项
  bool has_previous_error_{false};  // 是否已经保存过一次误差
};

}  // namespace simple_pid_controller

#endif  // SIMPLE_PID_CONTROLLER__SIMPLE_PID_HPP_
