#include "gtest/gtest.h"
#include "simple_pid_controller/simple_pid.hpp"

using simple_pid_controller::SimplePid;

// 只启用 Kp，验证输出等于 Kp 乘以误差。
TEST(SimplePid, ProportionalTerm)
{
  SimplePid pid(2.0, 0.0, 0.0, -100.0, 100.0, -10.0, 10.0);
  EXPECT_DOUBLE_EQ(pid.update(5.0, 3.0, 0.1), 4.0);
}

// 只启用 Ki，验证积分能够累计且不会超过配置的上限。
TEST(SimplePid, IntegralTermAccumulatesAndIsLimited)
{
  SimplePid pid(0.0, 1.0, 0.0, -100.0, 100.0, -0.5, 0.5);
  for (int index = 0; index < 10; ++index) {
    pid.update(1.0, 0.0, 0.1);
  }
  EXPECT_NEAR(pid.integral(), 0.5, 1e-12);
}

// 只启用 Kd，验证微分项使用相邻两次误差的变化率。
TEST(SimplePid, DerivativeTermUsesErrorChange)
{
  SimplePid pid(0.0, 0.0, 1.0, -100.0, 100.0, -10.0, 10.0);
  EXPECT_DOUBLE_EQ(pid.update(1.0, 0.0, 0.1), 0.0);
  EXPECT_NEAR(pid.update(2.0, 0.0, 0.1), 10.0, 1e-12);
}

// 即使 PID 原始结果很大，最终输出也必须受到上下限约束。
TEST(SimplePid, OutputIsLimited)
{
  SimplePid pid(10.0, 0.0, 0.0, -2.0, 2.0, -10.0, 10.0);
  EXPECT_DOUBLE_EQ(pid.update(10.0, 0.0, 0.1), 2.0);
  EXPECT_DOUBLE_EQ(pid.update(-10.0, 0.0, 0.1), -2.0);
}

// reset() 应清除积分和上一误差，使控制器能重新开始。
TEST(SimplePid, ResetClearsStoredState)
{
  SimplePid pid(0.0, 1.0, 1.0, -100.0, 100.0, -10.0, 10.0);
  pid.update(1.0, 0.0, 0.1);
  pid.reset();
  EXPECT_DOUBLE_EQ(pid.integral(), 0.0);
  EXPECT_DOUBLE_EQ(pid.update(1.0, 0.0, 0.1), 0.1);
}
