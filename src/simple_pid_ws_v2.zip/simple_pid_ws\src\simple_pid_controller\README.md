# simple_pid_controller

这是一个最小化的单变量 PID ROS 2 功能包。它只负责接收目标值和当前值，然后计算 PID 输出：

```text
误差 = 目标值 - 当前值
输出 = Kp × 误差 + Ki × 误差积分 + Kd × 误差变化率
```

它不包含航点、导航、TF、雷达、串口、飞控或可视化逻辑。

## 最推荐的使用方式：直接修改配置文件

打开下面这个文件：

```text
config/pid_params.yaml
```

找到以下两行并填写需要测试的数据：

```yaml
setpoint: 10.0     # 目标值
measurement: 3.0  # 当前值
```

同一个文件也可以设置 `Kp、Ki、Kd`、计算频率、积分上下限和输出上下限。修改后重新启动节点即可。

## ROS 2 接口

节点名称：`simple_pid_node`

| 方向 | 话题 | 类型 | 含义 |
|---|---|---|---|
| 订阅 | `/pid/setpoint` | `std_msgs/msg/Float64` | 运行时覆盖文件中的目标值 |
| 订阅 | `/pid/measurement` | `std_msgs/msg/Float64` | 运行时覆盖文件中的当前值 |
| 发布 | `/pid/output` | `std_msgs/msg/Float64` | PID 计算结果 |

即使不发布任何输入话题，节点也会直接使用 YAML 文件中的目标值和当前值进行计算。

## 配置参数

| 参数 | 默认值 | 含义 |
|---|---:|---|
| `setpoint` | `10.0` | 目标值 |
| `measurement` | `3.0` | 当前值 |
| `kp` | `1.0` | 比例系数 |
| `ki` | `0.0` | 积分系数 |
| `kd` | `0.0` | 微分系数 |
| `control_rate_hz` | `20.0` | 每秒计算次数 |
| `output_min` | `-10.0` | 输出下限 |
| `output_max` | `10.0` | 输出上限 |
| `integral_min` | `-10.0` | 积分下限 |
| `integral_max` | `10.0` | 积分上限 |

## 构建

在 Ubuntu 24.04 + ROS 2 Jazzy 中执行：

```bash
cd ~/simple_pid_ws
source /opt/ros/jazzy/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash
```

## 使用配置文件启动

终端 1：

```bash
ros2 launch simple_pid_controller pid.launch.py
```

终端 2：

```bash
ros2 topic echo /pid/output
```

默认配置为 `Kp=1、Ki=0、Kd=0`，目标值为 10、当前值为 3，因此输出为：

```text
误差 = 10 - 3 = 7
PID 输出 = 1 × 7 = 7
```

## 可选：运行时用话题修改输入值

节点运行以后，可以发送新目标值：

```bash
ros2 topic pub --once /pid/setpoint std_msgs/msg/Float64 "{data: 20.0}"
```

也可以持续发送变化的当前测量值：

```bash
ros2 topic pub -r 10 /pid/measurement std_msgs/msg/Float64 "{data: 5.0}"
```

话题输入会覆盖启动时从 YAML 文件读取的值，但不会修改 YAML 文件本身。重新启动节点后，会再次采用文件中的值。

## 测试

```bash
colcon test --packages-select simple_pid_controller
colcon test-result --verbose
```

测试覆盖比例项、积分项、微分项、积分限幅、输出限幅和状态重置。

以后进行无人机位置控制时，可以分别创建多个 PID 实例，例如 x 轴一个、y 轴一个、yaw 一个。当前功能包先保持单变量，便于理解和调试。
