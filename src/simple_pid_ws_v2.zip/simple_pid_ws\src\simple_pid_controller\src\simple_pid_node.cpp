#include <chrono>
#include <cmath>
#include <functional>
#include <memory>
#include <stdexcept>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float64.hpp"

#include "simple_pid_controller/simple_pid.hpp"

namespace simple_pid_controller
{

// 这个节点只负责三件事：
// 1. 读取目标值和当前值；
// 2. 按固定频率调用 SimplePid 计算；
// 3. 把计算结果发布到 /pid/output。
//
// 目标值和当前值有两种来源：
// - 启动时从 config/pid_params.yaml 读取；
// - 运行时由 /pid/setpoint 和 /pid/measurement 话题覆盖。
class SimplePidNode : public rclcpp::Node
{
public:
  SimplePidNode()
  : Node("simple_pid_node")
  {
    // ---------- 从 ROS 2 参数中读取 PID 配置 ----------
    // launch 文件会自动加载 config/pid_params.yaml。
    const double kp = declare_parameter<double>("kp", 1.0);
    const double ki = declare_parameter<double>("ki", 0.0);
    const double kd = declare_parameter<double>("kd", 0.0);
    const double output_min = declare_parameter<double>("output_min", -10.0);
    const double output_max = declare_parameter<double>("output_max", 10.0);
    const double integral_min = declare_parameter<double>("integral_min", -10.0);
    const double integral_max = declare_parameter<double>("integral_max", 10.0);
    control_rate_hz_ = declare_parameter<double>("control_rate_hz", 20.0);

    // 目标值和当前值也作为参数读取，因此用户只修改 YAML 文件就能直接测试。
    setpoint_ = declare_parameter<double>("setpoint", 10.0);
    measurement_ = declare_parameter<double>("measurement", 3.0);

    if (!std::isfinite(control_rate_hz_) || control_rate_hz_ <= 0.0 ||
      !std::isfinite(setpoint_) || !std::isfinite(measurement_))
    {
      throw std::invalid_argument(
              "control rate, setpoint, and measurement must be finite; rate must be positive");
    }

    // 创建真正执行 PID 数学运算的对象。
    pid_ = std::make_unique<SimplePid>(
      kp, ki, kd, output_min, output_max, integral_min, integral_max);

    // ---------- 创建可选的话题输入 ----------
    // YAML 文件中的值可以让节点直接运行；如果话题收到新值，就用新值覆盖文件值。
    setpoint_subscription_ = create_subscription<std_msgs::msg::Float64>(
      "pid/setpoint", 10,
      std::bind(&SimplePidNode::setpoint_callback, this, std::placeholders::_1));
    measurement_subscription_ = create_subscription<std_msgs::msg::Float64>(
      "pid/measurement", 10,
      std::bind(&SimplePidNode::measurement_callback, this, std::placeholders::_1));

    // PID 结果使用一个普通 Float64 消息发布。
    output_publisher_ = create_publisher<std_msgs::msg::Float64>("pid/output", 10);

    // ---------- 创建固定周期的计算定时器 ----------
    // 例如 control_rate_hz=20 时，每 0.05 秒计算一次。
    const auto period = std::chrono::duration<double>(1.0 / control_rate_hz_);
    timer_ = create_wall_timer(
      std::chrono::duration_cast<std::chrono::nanoseconds>(period),
      std::bind(&SimplePidNode::calculate, this));

    RCLCPP_INFO(
      get_logger(),
      "Simple PID started: target=%.3f, current=%.3f, kp=%.3f, ki=%.3f, "
      "kd=%.3f, rate=%.1f Hz",
      setpoint_, measurement_, kp, ki, kd, control_rate_hz_);
  }

private:
  // 收到新的目标值后，直接覆盖 YAML 文件提供的初始目标值。
  void setpoint_callback(const std_msgs::msg::Float64::SharedPtr message)
  {
    if (!std::isfinite(message->data)) {
      RCLCPP_WARN(get_logger(), "Ignoring a non-finite setpoint");
      return;
    }
    setpoint_ = message->data;
  }

  // 收到新的当前值后，直接覆盖 YAML 文件提供的初始当前值。
  void measurement_callback(const std_msgs::msg::Float64::SharedPtr message)
  {
    if (!std::isfinite(message->data)) {
      RCLCPP_WARN(get_logger(), "Ignoring a non-finite measurement");
      return;
    }
    measurement_ = message->data;
  }

  // 定时器每到一个控制周期就会调用这个函数。
  void calculate()
  {
    // 本节点使用固定频率，因此 dt 可以直接由控制频率计算。
    const double dt = 1.0 / control_rate_hz_;

    // 调用纯 C++ PID 类得到结果，再封装成 ROS 2 消息发布。
    std_msgs::msg::Float64 output;
    output.data = pid_->update(setpoint_, measurement_, dt);
    output_publisher_->publish(output);
  }

  double control_rate_hz_{20.0};  // PID 每秒计算次数
  double setpoint_{10.0};         // 当前目标值
  double measurement_{3.0};      // 当前测量值

  // PID 数学对象。
  std::unique_ptr<SimplePid> pid_;

  // 两个订阅者允许其他节点在运行过程中修改目标值和当前值。
  rclcpp::Subscription<std_msgs::msg::Float64>::SharedPtr setpoint_subscription_;
  rclcpp::Subscription<std_msgs::msg::Float64>::SharedPtr measurement_subscription_;

  // 发布 PID 计算结果。
  rclcpp::Publisher<std_msgs::msg::Float64>::SharedPtr output_publisher_;

  // 按 control_rate_hz 周期触发 calculate()。
  rclcpp::TimerBase::SharedPtr timer_;
};

}  // namespace simple_pid_controller

int main(int argc, char ** argv)
{
  // 初始化 ROS 2。
  rclcpp::init(argc, argv);

  // 创建节点并持续处理订阅回调和定时器回调。
  rclcpp::spin(std::make_shared<simple_pid_controller::SimplePidNode>());

  // 节点退出后清理 ROS 2 资源。
  rclcpp::shutdown();
  return 0;
}
