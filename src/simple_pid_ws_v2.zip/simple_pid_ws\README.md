# Simple PID ROS 2 Workspace

这是一个最小化的 ROS 2 PID 学习工作区，只包含 `simple_pid_controller` 一个功能包。

目标值、当前值和 PID 参数都可以直接在 `src/simple_pid_controller/config/pid_params.yaml` 中修改。

详细说明见 [`src/simple_pid_controller/README.md`](src/simple_pid_controller/README.md)。
