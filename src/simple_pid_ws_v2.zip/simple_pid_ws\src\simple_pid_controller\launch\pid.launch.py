import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    # 找到安装后的功能包目录，再定位默认 YAML 配置文件。
    package_directory = get_package_share_directory("simple_pid_controller")
    default_params_file = os.path.join(package_directory, "config", "pid_params.yaml")

    # params_file 是一个可替换的启动参数。
    # 默认使用包内的 pid_params.yaml，也允许以后传入另一份配置文件。
    params_file_argument = DeclareLaunchArgument(
        "params_file",
        default_value=default_params_file,
        description="PID 参数、目标值和当前值所在的 YAML 文件",
    )

    # 创建唯一的 PID 节点，并将整份 YAML 文件作为节点参数加载。
    pid_node = Node(
        package="simple_pid_controller",
        executable="simple_pid_node",
        name="simple_pid_node",
        output="screen",
        parameters=[LaunchConfiguration("params_file")],
    )

    return LaunchDescription([params_file_argument, pid_node])
