#ifndef MAP_COORDINATE_PROVIDER__POSE_MATH_HPP_
#define MAP_COORDINATE_PROVIDER__POSE_MATH_HPP_

#include <cmath>

namespace map_coordinate_provider
{

/**
 * @brief 归一化后的四元数以及由它计算得到的 yaw。
 *
 * PoseStamped 必须继续保存完整四元数，不能只把 yaw 填进 orientation.z。
 * yaw 只用于日志和测试；新版 PID 会从完整四元数中自行提取 yaw。
 */
struct NormalizedQuaternionYaw
{
  double x{0.0};
  double y{0.0};
  double z{0.0};
  double w{1.0};
  double yaw{0.0};
};

/// x、y、z 三个位置分量必须全部为有限数值。
inline bool position_is_finite(double x, double y, double z)
{
  return std::isfinite(x) && std::isfinite(y) && std::isfinite(z);
}

/**
 * @brief 检查、归一化四元数并计算 yaw。
 * @return 输入有效时返回 true；全零、NaN 或 Inf 四元数返回 false。
 */
inline bool normalize_quaternion_and_get_yaw(
  double x, double y, double z, double w,
  NormalizedQuaternionYaw & result)
{
  if (!std::isfinite(x) || !std::isfinite(y) ||
    !std::isfinite(z) || !std::isfinite(w))
  {
    return false;
  }

  const double norm = std::hypot(std::hypot(x, y), std::hypot(z, w));
  if (!std::isfinite(norm) || norm < 1.0e-12) {
    return false;
  }

  result.x = x / norm;
  result.y = y / norm;
  result.z = z / norm;
  result.w = w / norm;

  // 标准四元数转 yaw 公式，结果自然位于 [-pi, pi]。
  const double sin_yaw = 2.0 * (result.w * result.z + result.x * result.y);
  const double cos_yaw =
    1.0 - 2.0 * (result.y * result.y + result.z * result.z);
  result.yaw = std::atan2(sin_yaw, cos_yaw);
  return std::isfinite(result.yaw);
}

}  // namespace map_coordinate_provider

#endif  // MAP_COORDINATE_PROVIDER__POSE_MATH_HPP_
