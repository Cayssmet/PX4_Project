#include <algorithm>
#include <chrono>
#include <cmath>
#include <functional>
#include <memory>
#include <stdexcept>
#include <string>

#include "geometry_msgs/msg/pose_stamped.hpp"
#include "geometry_msgs/msg/twist_stamped.hpp"
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/bool.hpp"
#include "tf2/LinearMath/Matrix3x3.h"
#include "tf2/LinearMath/Quaternion.h"

#include "position_pid_controller/control_math.hpp"
#include "position_pid_controller/pid_axis.hpp"

namespace position_pid_controller
{

/**
 * @brief 同时控制地图坐标系 x、y、yaw 的 ROS 2 节点。
 *
 * 本节点只生成地图坐标系下的期望平移速度和偏航角速度，不负责高度、姿态、
 * 电机或串口通信。后续应由飞控执行层完成坐标变换、限幅和真机安全保护。
 */
class PositionPidNode : public rclcpp::Node
{
public:
  PositionPidNode()
  : Node("position_pid_controller")
  {
    // ---------- 通用参数 ----------
    map_frame_ = declare_parameter<std::string>("map_frame", "map");
    control_rate_hz_ = declare_parameter<double>("control_rate_hz", 20.0);
    pose_timeout_ms_ = declare_parameter<int>("pose_timeout_ms", 500);
    valid_timeout_ms_ = declare_parameter<int>("valid_timeout_ms", 500);
    print_status_ = declare_parameter<bool>("print_status", true);

    // ---------- YAML 中的初始目标；后续可由 /pid/target_pose 覆盖 ----------
    target_x_ = declare_parameter<double>("target_x", 0.0);
    target_y_ = declare_parameter<double>("target_y", 0.0);
    target_yaw_ = wrap_angle(declare_parameter<double>("target_yaw", 0.0));

    const double derivative_filter_alpha =
      declare_parameter<double>("derivative_filter_alpha", 0.8);

    // ---------- x 轴 PID ----------
    const double x_kp = declare_parameter<double>("x_kp", 1.0);
    const double x_ki = declare_parameter<double>("x_ki", 0.0);
    const double x_kd = declare_parameter<double>("x_kd", 0.0);
    const double x_integral_limit = declare_parameter<double>("x_integral_limit", 1.0);
    const double x_output_limit = declare_parameter<double>("x_output_limit", 0.8);

    // ---------- y 轴 PID ----------
    const double y_kp = declare_parameter<double>("y_kp", 1.0);
    const double y_ki = declare_parameter<double>("y_ki", 0.0);
    const double y_kd = declare_parameter<double>("y_kd", 0.0);
    const double y_integral_limit = declare_parameter<double>("y_integral_limit", 1.0);
    const double y_output_limit = declare_parameter<double>("y_output_limit", 0.8);

    // ---------- yaw 轴 PID ----------
    const double yaw_kp = declare_parameter<double>("yaw_kp", 1.0);
    const double yaw_ki = declare_parameter<double>("yaw_ki", 0.0);
    const double yaw_kd = declare_parameter<double>("yaw_kd", 0.0);
    const double yaw_integral_limit =
      declare_parameter<double>("yaw_integral_limit", 1.0);
    const double yaw_output_limit = declare_parameter<double>("yaw_output_limit", 0.8);

    // ---------- 最小/最大速度与迟滞阈值 ----------
    min_xy_speed_ = declare_parameter<double>("min_xy_speed", 0.15);
    max_xy_speed_ = declare_parameter<double>("max_xy_speed", 0.80);
    min_yaw_rate_ = declare_parameter<double>("min_yaw_rate", 0.10);
    max_yaw_rate_ = declare_parameter<double>("max_yaw_rate", 0.80);

    const double position_enter_tolerance =
      declare_parameter<double>("position_enter_tolerance", 0.10);
    const double position_exit_tolerance =
      declare_parameter<double>("position_exit_tolerance", 0.15);
    const double yaw_enter_tolerance =
      declare_parameter<double>("yaw_enter_tolerance", 0.10);
    const double yaw_exit_tolerance =
      declare_parameter<double>("yaw_exit_tolerance", 0.15);

    validate_node_parameters();

    // 三个 PID 各自保存状态，位置保持和 yaw 保持也互不影响。
    x_pid_ = std::make_unique<PidAxis>(
      x_kp, x_ki, x_kd, x_integral_limit, x_output_limit,
      derivative_filter_alpha);
    y_pid_ = std::make_unique<PidAxis>(
      y_kp, y_ki, y_kd, y_integral_limit, y_output_limit,
      derivative_filter_alpha);
    yaw_pid_ = std::make_unique<PidAxis>(
      yaw_kp, yaw_ki, yaw_kd, yaw_integral_limit, yaw_output_limit,
      derivative_filter_alpha);

    position_hold_ = std::make_unique<HysteresisHold>(
      position_enter_tolerance, position_exit_tolerance);
    yaw_hold_ = std::make_unique<HysteresisHold>(
      yaw_enter_tolerance, yaw_exit_tolerance);

    cmd_vel_publisher_ =
      create_publisher<geometry_msgs::msg::TwistStamped>("/pid/cmd_vel", 10);
    control_valid_publisher_ =
      create_publisher<std_msgs::msg::Bool>("/pid/control_valid", 10);
    target_reached_publisher_ =
      create_publisher<std_msgs::msg::Bool>("/pid/target_reached", 10);

    const auto reliable_qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
    pose_subscription_ = create_subscription<geometry_msgs::msg::PoseStamped>(
      "/map/current_pose", reliable_qos,
      std::bind(&PositionPidNode::pose_callback, this, std::placeholders::_1));
    pose_valid_subscription_ = create_subscription<std_msgs::msg::Bool>(
      "/map/current_pose_valid", reliable_qos,
      std::bind(&PositionPidNode::pose_valid_callback, this, std::placeholders::_1));
    target_subscription_ = create_subscription<geometry_msgs::msg::PoseStamped>(
      "/pid/target_pose", reliable_qos,
      std::bind(&PositionPidNode::target_callback, this, std::placeholders::_1));

    const auto timer_period = std::chrono::duration_cast<std::chrono::nanoseconds>(
      std::chrono::duration<double>(1.0 / control_rate_hz_));
    control_timer_ = create_wall_timer(
      timer_period, std::bind(&PositionPidNode::control_timer_callback, this));

    RCLCPP_INFO(
      get_logger(),
      "位置 PID 已启动：目标=(%.3f, %.3f, %.3f rad)，控制频率=%.1f Hz，frame=%s",
      target_x_, target_y_, target_yaw_, control_rate_hz_, map_frame_.c_str());
    RCLCPP_WARN(
      get_logger(),
      "当前参数仅用于建图与闭环联调；真机前必须重新标定，并增加飞控执行层安全保护。");
  }

private:
  void validate_node_parameters() const
  {
    if (map_frame_.empty()) {
      throw std::invalid_argument("map_frame 不能为空");
    }
    if (!std::isfinite(control_rate_hz_) || control_rate_hz_ <= 0.0) {
      throw std::invalid_argument("control_rate_hz 必须大于 0");
    }
    if (pose_timeout_ms_ <= 0 || valid_timeout_ms_ <= 0) {
      throw std::invalid_argument("pose_timeout_ms 和 valid_timeout_ms 必须大于 0");
    }
    if (!std::isfinite(target_x_) || !std::isfinite(target_y_) ||
      !std::isfinite(target_yaw_))
    {
      throw std::invalid_argument("YAML 初始目标必须是有限数值");
    }
    validate_speed_limits(min_xy_speed_, max_xy_speed_);
    validate_speed_limits(min_yaw_rate_, max_yaw_rate_);
  }

  /**
   * @brief 检查四元数并提取 yaw。
   *
   * SLAM 位姿仍使用完整四元数；这里只提取 yaw 供平面位置控制器使用。
   */
  static bool quaternion_to_yaw(
    const geometry_msgs::msg::Quaternion & orientation, double & yaw)
  {
    if (!std::isfinite(orientation.x) || !std::isfinite(orientation.y) ||
      !std::isfinite(orientation.z) || !std::isfinite(orientation.w))
    {
      return false;
    }

    tf2::Quaternion quaternion(
      orientation.x, orientation.y, orientation.z, orientation.w);
    const double norm_squared = quaternion.length2();
    if (!std::isfinite(norm_squared) || norm_squared < 1.0e-12) {
      return false;
    }
    quaternion.normalize();

    double roll = 0.0;
    double pitch = 0.0;
    tf2::Matrix3x3(quaternion).getRPY(roll, pitch, yaw);
    (void)roll;
    (void)pitch;
    return std::isfinite(yaw);
  }

  void pose_callback(const geometry_msgs::msg::PoseStamped::SharedPtr message)
  {
    if (message->header.frame_id != map_frame_) {
      has_pose_ = false;
      RCLCPP_WARN_THROTTLE(
        get_logger(), *get_clock(), 2000,
        "拒绝当前位姿：frame_id 应为 '%s'，实际为 '%s'",
        map_frame_.c_str(), message->header.frame_id.c_str());
      return;
    }

    const auto & position = message->pose.position;
    double yaw = 0.0;
    if (!std::isfinite(position.x) || !std::isfinite(position.y) ||
      !quaternion_to_yaw(message->pose.orientation, yaw))
    {
      has_pose_ = false;
      RCLCPP_WARN_THROTTLE(
        get_logger(), *get_clock(), 2000,
        "拒绝当前位姿：x/y 或姿态四元数非法");
      return;
    }

    current_x_ = position.x;
    current_y_ = position.y;
    current_yaw_ = wrap_angle(yaw);
    current_pose_stamp_ = rclcpp::Time(
      message->header.stamp, get_clock()->get_clock_type());
    has_pose_ = true;
  }

  void pose_valid_callback(const std_msgs::msg::Bool::SharedPtr message)
  {
    pose_valid_ = message->data;
    has_pose_valid_message_ = true;
    pose_valid_received_time_ = now();
  }

  void target_callback(const geometry_msgs::msg::PoseStamped::SharedPtr message)
  {
    if (message->header.frame_id != map_frame_) {
      RCLCPP_WARN(
        get_logger(), "拒绝目标：frame_id 应为 '%s'，实际为 '%s'",
        map_frame_.c_str(), message->header.frame_id.c_str());
      return;
    }

    const auto & position = message->pose.position;
    double yaw = 0.0;
    if (!std::isfinite(position.x) || !std::isfinite(position.y) ||
      !quaternion_to_yaw(message->pose.orientation, yaw))
    {
      RCLCPP_WARN(get_logger(), "拒绝目标：x/y 或姿态四元数非法");
      return;
    }

    target_x_ = position.x;
    target_y_ = position.y;
    target_yaw_ = wrap_angle(yaw);

    // 新目标与旧目标没有连续性，必须清除旧目标积累的全部控制状态。
    reset_controller_state();
    RCLCPP_INFO(
      get_logger(), "收到新目标：x=%.3f m, y=%.3f m, yaw=%.3f rad",
      target_x_, target_y_, target_yaw_);
  }

  std::string invalid_reason(const rclcpp::Time & current_time) const
  {
    if (!has_pose_) {
      return "尚未收到合法的 /map/current_pose";
    }
    if (!has_pose_valid_message_) {
      return "尚未收到 /map/current_pose_valid";
    }
    if (!pose_valid_) {
      return "地图坐标提供者报告 valid=false";
    }
    if (current_pose_stamp_.nanoseconds() <= 0) {
      return "当前位姿的 header.stamp 为空";
    }

    const double pose_age_ms = (current_time - current_pose_stamp_).seconds() * 1000.0;
    if (!std::isfinite(pose_age_ms) || pose_age_ms < 0.0) {
      return "当前位姿时间戳来自未来或时钟发生回退";
    }
    if (pose_age_ms > static_cast<double>(pose_timeout_ms_)) {
      return "当前位姿已经超时";
    }

    const double valid_age_ms =
      (current_time - pose_valid_received_time_).seconds() * 1000.0;
    if (!std::isfinite(valid_age_ms) || valid_age_ms < 0.0) {
      return "有效标志计时异常";
    }
    if (valid_age_ms > static_cast<double>(valid_timeout_ms_)) {
      return "当前位姿有效标志已经超时";
    }
    return "";
  }

  void control_timer_callback()
  {
    const rclcpp::Time current_time = now();
    const std::string reason = invalid_reason(current_time);
    if (!reason.empty()) {
      reset_controller_state();
      publish_output(current_time, 0.0, 0.0, 0.0, false, false);
      RCLCPP_WARN_THROTTLE(
        get_logger(), *get_clock(), 2000, "控制无效并输出零速度：%s", reason.c_str());
      return;
    }

    const double nominal_dt = 1.0 / control_rate_hz_;
    // 允许偶发调度抖动；低控制频率时阈值随周期放宽，避免把正常周期误判为异常。
    const double maximum_dt = std::max(0.5, 5.0 * nominal_dt);
    double dt_sec = nominal_dt;
    if (has_last_control_time_) {
      dt_sec = (current_time - last_control_time_).seconds();
      // dt 过大时，积分和微分都不再可信。本周期安全地输出零并重置状态。
      if (!std::isfinite(dt_sec) || dt_sec <= 0.0 || dt_sec > maximum_dt) {
        reset_controller_state();
        publish_output(current_time, 0.0, 0.0, 0.0, false, false);
        RCLCPP_WARN_THROTTLE(
          get_logger(), *get_clock(), 2000,
          "控制计时异常（dt=%.6f s），本周期输出零速度", dt_sec);
        return;
      }
    }
    last_control_time_ = current_time;
    has_last_control_time_ = true;

    const double error_x = target_x_ - current_x_;
    const double error_y = target_y_ - current_y_;
    const double position_error = std::hypot(error_x, error_y);
    const double yaw_error = wrap_angle(target_yaw_ - current_yaw_);

    const bool position_holding = position_hold_->update(position_error);
    const bool yaw_holding = yaw_hold_->update(std::abs(yaw_error));

    double command_x = 0.0;
    double command_y = 0.0;
    if (position_holding) {
      // 进入位置保持区后持续清空积分，防止恢复运动时旧积分突然释放。
      x_pid_->reset();
      y_pid_->reset();
    } else {
      const double raw_x = x_pid_->update_error(error_x, dt_sec);
      const double raw_y = y_pid_->update_error(error_y, dt_sec);
      const PlanarCommand limited = apply_planar_speed_limits(
        raw_x, raw_y, error_x, error_y, min_xy_speed_, max_xy_speed_);
      command_x = limited.x;
      command_y = limited.y;
    }

    double command_yaw_rate = 0.0;
    if (yaw_holding) {
      yaw_pid_->reset();
    } else {
      const double raw_yaw_rate = yaw_pid_->update_error(yaw_error, dt_sec);
      command_yaw_rate = apply_yaw_rate_limits(
        raw_yaw_rate, yaw_error, min_yaw_rate_, max_yaw_rate_);
    }

    const bool target_reached = position_holding && yaw_holding;
    publish_output(
      current_time, command_x, command_y, command_yaw_rate, true, target_reached);

    if (print_status_) {
      RCLCPP_INFO_THROTTLE(
        get_logger(), *get_clock(), 1000,
        "误差：位置=%.3f m, yaw=%.3f rad；输出：vx=%.3f, vy=%.3f, yaw_rate=%.3f；到达=%s",
        position_error, yaw_error, command_x, command_y, command_yaw_rate,
        target_reached ? "true" : "false");
    }
  }

  void publish_output(
    const rclcpp::Time & stamp,
    double velocity_x, double velocity_y, double yaw_rate,
    bool control_valid, bool target_reached)
  {
    geometry_msgs::msg::TwistStamped command;
    command.header.stamp = stamp;
    command.header.frame_id = map_frame_;
    command.twist.linear.x = velocity_x;
    command.twist.linear.y = velocity_y;
    command.twist.angular.z = yaw_rate;
    cmd_vel_publisher_->publish(command);

    std_msgs::msg::Bool valid_message;
    valid_message.data = control_valid;
    control_valid_publisher_->publish(valid_message);

    std_msgs::msg::Bool reached_message;
    reached_message.data = target_reached;
    target_reached_publisher_->publish(reached_message);
  }

  void reset_controller_state()
  {
    x_pid_->reset();
    y_pid_->reset();
    yaw_pid_->reset();
    position_hold_->reset();
    yaw_hold_->reset();
    has_last_control_time_ = false;
  }

  // ---------- 参数 ----------
  std::string map_frame_;
  double control_rate_hz_{20.0};
  int pose_timeout_ms_{500};
  int valid_timeout_ms_{500};
  bool print_status_{true};

  double target_x_{0.0};
  double target_y_{0.0};
  double target_yaw_{0.0};
  double min_xy_speed_{0.15};
  double max_xy_speed_{0.80};
  double min_yaw_rate_{0.10};
  double max_yaw_rate_{0.80};

  // ---------- 当前状态与时间 ----------
  double current_x_{0.0};
  double current_y_{0.0};
  double current_yaw_{0.0};
  bool has_pose_{false};
  bool has_pose_valid_message_{false};
  bool pose_valid_{false};
  bool has_last_control_time_{false};
  rclcpp::Time current_pose_stamp_{0, 0, RCL_ROS_TIME};
  rclcpp::Time pose_valid_received_time_{0, 0, RCL_ROS_TIME};
  rclcpp::Time last_control_time_{0, 0, RCL_ROS_TIME};

  // ---------- 控制核心 ----------
  std::unique_ptr<PidAxis> x_pid_;
  std::unique_ptr<PidAxis> y_pid_;
  std::unique_ptr<PidAxis> yaw_pid_;
  std::unique_ptr<HysteresisHold> position_hold_;
  std::unique_ptr<HysteresisHold> yaw_hold_;

  // ---------- ROS 2 接口 ----------
  rclcpp::Publisher<geometry_msgs::msg::TwistStamped>::SharedPtr cmd_vel_publisher_;
  rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr control_valid_publisher_;
  rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr target_reached_publisher_;
  rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr pose_subscription_;
  rclcpp::Subscription<std_msgs::msg::Bool>::SharedPtr pose_valid_subscription_;
  rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr target_subscription_;
  rclcpp::TimerBase::SharedPtr control_timer_;
};

}  // namespace position_pid_controller

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<position_pid_controller::PositionPidNode>());
  rclcpp::shutdown();
  return 0;
}
