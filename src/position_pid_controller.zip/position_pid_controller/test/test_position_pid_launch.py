"""位置 PID 节点的 ROS 2 接口与输入失效保护集成测试。"""

import os
import time

from ament_index_python.packages import get_package_share_directory
from geometry_msgs.msg import PoseStamped, TwistStamped
import launch
import launch_ros.actions
import launch_testing.actions
import launch_testing.asserts
import pytest
import rclpy
from std_msgs.msg import Bool


@pytest.mark.launch_test
def generate_test_description():
    params_file = os.path.join(
        get_package_share_directory("position_pid_controller"),
        "config",
        "position_pid_params.yaml",
    )

    # 加载真正的 YAML，再只覆盖测试所需参数；这也能发现 YAML 结构或参数名错误。
    pid_process = launch_ros.actions.Node(
        package="position_pid_controller",
        executable="position_pid_node",
        name="position_pid_controller",
        output="screen",
        parameters=[
            params_file,
            {
                "target_x": 1.0,
                "target_y": 0.0,
                "target_yaw": 0.0,
                "x_kp": 0.01,
                "y_kp": 0.01,
                "yaw_kp": 0.01,
                "pose_timeout_ms": 300,
                "valid_timeout_ms": 300,
                "print_status": False,
            },
        ],
    )

    return launch.LaunchDescription(
        [pid_process, launch_testing.actions.ReadyToTest()]
    ), {"pid_process": pid_process}


class TestPositionPidNode:
    @classmethod
    def setup_class(cls):
        rclpy.init()
        cls.node = rclpy.create_node("position_pid_integration_test")

        cls.pose_publisher = cls.node.create_publisher(
            PoseStamped, "/map/current_pose", 10
        )
        cls.valid_publisher = cls.node.create_publisher(
            Bool, "/map/current_pose_valid", 10
        )
        cls.target_publisher = cls.node.create_publisher(
            PoseStamped, "/pid/target_pose", 10
        )

        cls.latest_command = None
        cls.latest_control_valid = None
        cls.latest_target_reached = None
        cls.command_count = 0
        cls.valid_count = 0
        cls.reached_count = 0

        cls.node.create_subscription(
            TwistStamped, "/pid/cmd_vel", cls._command_callback, 10
        )
        cls.node.create_subscription(
            Bool, "/pid/control_valid", cls._valid_callback, 10
        )
        cls.node.create_subscription(
            Bool, "/pid/target_reached", cls._reached_callback, 10
        )

        # 等待 DDS 发现完成，避免第一批测试消息在订阅匹配前丢失。
        cls._wait_for(
            lambda: cls.pose_publisher.get_subscription_count() > 0
            and cls.valid_publisher.get_subscription_count() > 0
            and cls.target_publisher.get_subscription_count() > 0,
            timeout=5.0,
        )

    @classmethod
    def teardown_class(cls):
        cls.node.destroy_node()
        rclpy.shutdown()

    @classmethod
    def _command_callback(cls, message):
        cls.latest_command = message
        cls.command_count += 1

    @classmethod
    def _valid_callback(cls, message):
        cls.latest_control_valid = message.data
        cls.valid_count += 1

    @classmethod
    def _reached_callback(cls, message):
        cls.latest_target_reached = message.data
        cls.reached_count += 1

    @classmethod
    def _wait_for(cls, predicate, timeout=2.0):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            rclpy.spin_once(cls.node, timeout_sec=0.05)
            if predicate():
                return
        raise AssertionError("等待 ROS 2 测试条件超时")

    @classmethod
    def _pose(cls, x=0.0, y=0.0, frame="map", valid_quaternion=True):
        message = PoseStamped()
        message.header.stamp = cls.node.get_clock().now().to_msg()
        message.header.frame_id = frame
        message.pose.position.x = x
        message.pose.position.y = y
        if valid_quaternion:
            message.pose.orientation.w = 1.0
        # valid_quaternion=false 时保持全零四元数，用来验证非法输入保护。
        return message

    @classmethod
    def _publish_state(cls, pose, valid=True):
        cls.pose_publisher.publish(pose)
        valid_message = Bool()
        valid_message.data = valid
        cls.valid_publisher.publish(valid_message)

    @classmethod
    def _wait_for_new_output(cls, predicate, timeout=2.0):
        start_command_count = cls.command_count
        start_valid_count = cls.valid_count
        start_reached_count = cls.reached_count
        cls._wait_for(
            lambda: cls.command_count > start_command_count
            and cls.valid_count > start_valid_count
            and cls.reached_count > start_reached_count
            and predicate(),
            timeout=timeout,
        )

    def test_complete_control_and_safety_sequence(self):
        # 未提供坐标时，节点仍持续输出零命令，但 control_valid 必须为 false。
        self._wait_for_new_output(
            lambda: self.latest_control_valid is False
            and self.latest_command.twist.linear.x == 0.0
            and self.latest_command.twist.linear.y == 0.0
            and self.latest_command.twist.angular.z == 0.0
        )

        # YAML 目标为 x=1；当前位置为 0，较小 Kp 产生的输出应被提升到最小速度。
        self._publish_state(self._pose(0.0, 0.0), valid=True)
        self._wait_for_new_output(
            lambda: self.latest_control_valid is True
            and abs(self.latest_command.twist.linear.x - 0.15) < 1.0e-6
            and abs(self.latest_command.twist.linear.y) < 1.0e-12
            and self.latest_target_reached is False
        )

        # topic 新目标覆盖 YAML 目标；当前位姿正好位于新目标，三轴应进入保持。
        self.target_publisher.publish(self._pose(0.0, 0.0))
        self._wait_for_new_output(
            lambda: self.latest_control_valid is True
            and self.latest_target_reached is True
            and self.latest_command.twist.linear.x == 0.0
            and self.latest_command.twist.linear.y == 0.0
            and self.latest_command.twist.angular.z == 0.0
        )

        # 错误 frame 必须立即使当前位姿无效，不能继续使用上一帧。
        self._publish_state(self._pose(frame="odom"), valid=True)
        self._wait_for_new_output(
            lambda: self.latest_control_valid is False
            and self.latest_command.twist.linear.x == 0.0
        )

        # 全零四元数同样属于非法位姿。
        self._publish_state(
            self._pose(valid_quaternion=False), valid=True
        )
        self._wait_for_new_output(
            lambda: self.latest_control_valid is False
            and self.latest_command.twist.angular.z == 0.0
        )

        # 即使位姿本身合法，valid=false 也必须关闭控制。
        self._publish_state(self._pose(), valid=False)
        self._wait_for_new_output(
            lambda: self.latest_control_valid is False
            and self.latest_target_reached is False
        )

        # 恢复合法输入后控制恢复；停止发送后，300 ms 超时保护再次输出无效零速度。
        self._publish_state(self._pose(), valid=True)
        self._wait_for_new_output(
            lambda: self.latest_control_valid is True
            and self.latest_target_reached is True
        )
        self._wait_for_new_output(
            lambda: self.latest_control_valid is False
            and self.latest_command.twist.linear.x == 0.0,
            timeout=1.5,
        )


@launch_testing.post_shutdown_test()
class TestProcessExit:
    def test_node_exits_cleanly(self, proc_info):
        """测试结束关闭 launch 时，节点不应因异常崩溃。"""
        launch_testing.asserts.assertExitCodes(proc_info)
