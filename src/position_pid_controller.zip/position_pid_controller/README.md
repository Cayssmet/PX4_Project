# position_pid_controller

这是运行在树莓派 Ubuntu 24.04、ROS 2 Jazzy 上的三轴位置 PID 功能包。它同时完成：

- `x 位置误差 -> vx`
- `y 位置误差 -> vy`
- `yaw 最短角度误差 -> yaw_rate`

它直接订阅 `map_coordinate_provider` 给出的完整地图位姿，不再使用旧的单变量
`/pid/setpoint`、`/pid/measurement` 和 `/pid/output`。

> 这个包只输出**地图坐标系速度目标**，不直接控制姿态、电机或串口。真机还需要
> 串口/飞控执行层、坐标转换、失联保护、急停和经过实际测试的参数。

## 一、数据关系

```text
雷达 + SLAM
    -> TF: map 到 base_link
    -> map_coordinate_provider
       ├─ /map/current_pose
       └─ /map/current_pose_valid
              ↓
       position_pid_controller
       ├─ /pid/cmd_vel
       ├─ /pid/control_valid
       └─ /pid/target_reached
              ↓
       后续串口/飞控执行层（本包不包含）
```

## 二、ROS 2 接口

| 方向 | 话题 | 消息类型 | 含义 |
|---|---|---|---|
| 订阅 | `/map/current_pose` | `geometry_msgs/msg/PoseStamped` | SLAM 得到的当前完整位姿 |
| 订阅 | `/map/current_pose_valid` | `std_msgs/msg/Bool` | 当前位姿是否有效，必须持续更新 |
| 订阅 | `/pid/target_pose` | `geometry_msgs/msg/PoseStamped` | 运行时新目标，覆盖 YAML 目标 |
| 发布 | `/pid/cmd_vel` | `geometry_msgs/msg/TwistStamped` | `linear.x=vx`、`linear.y=vy`、`angular.z=yaw_rate` |
| 发布 | `/pid/control_valid` | `std_msgs/msg/Bool` | 本周期控制结果是否可用 |
| 发布 | `/pid/target_reached` | `std_msgs/msg/Bool` | 位置与 yaw 是否都处于保持区 |

当前位姿和运行时目标的 `header.frame_id` 都必须是 `map`（或配置中的
`map_frame`）。输出 `/pid/cmd_vel` 的 frame 也固定为该地图坐标系。

## 三、最小速度为什么不会导致目标附近一直振荡

仅仅设置最小速度会带来一个问题：飞行器接近目标以后，仍可能以最小速度来回越过
目标。因此本包把“最小速度”和“双阈值保持”配套使用：

1. 位置误差在 `0.10 m` 以外时正常跟踪。合成速度小于 `0.15 m/s` 时，提高到
   `0.15 m/s`；如果 PID 恰好输出零，则沿当前位置指向目标的方向输出最小速度。
2. 位置误差进入 `0.10 m` 后，`vx`、`vy` 严格变为零并清空 x/y 积分。
3. 漂移后只要误差还不大于 `0.15 m`，仍保持零；超过 `0.15 m` 才恢复移动。
4. yaw 使用独立的 `0.10 rad` 进入阈值和 `0.15 rad` 退出阈值，互不干扰。

x/y 最后按**矢量模长**执行 `max_xy_speed` 限制，所以对角线运动也不会超速。
yaw 误差先归一化到 `[-pi, pi]`，例如从 `+179°` 到 `-179°` 只旋转约 `2°`。

## 四、直接修改目标和全部参数

编辑源码包中的：

```text
/home/ljz/ros2_ws/src/position_pid_controller/config/position_pid_params.yaml
```

文件内已经为每一项添加中文说明。最常修改的是：

```yaml
target_x: 2.0
target_y: 1.0
target_yaw: 0.0

x_kp: 1.0
x_ki: 0.0
x_kd: 0.0
# y、yaw 也分别拥有 Kp、Ki、Kd

min_xy_speed: 0.15
max_xy_speed: 0.80
min_yaw_rate: 0.10
max_yaw_rate: 0.80
```

这里的 yaw 单位是弧度：`90° = 1.5708 rad`，`180° = 3.1416 rad`。
修改 YAML 后重新启动节点即可；如果参数没有更新，重新执行一次带
`--symlink-install` 的构建并重新 source。

调参建议先令 `Ki=0、Kd=0`，从较小的 `Kp` 开始确认坐标方向，再逐步调节。最小
速度必须依据飞行器在真实环境中克服风扰和执行死区所需的速度确定，不能把默认值
直接当作真机结论。

## 五、放入现有工作空间

压缩包内第一层就是真正的 `position_pid_controller/` package。解压后结构应为：

```text
/home/ljz/ros2_ws/
└── src/
    ├── position_pid_controller/
    ├── map_coordinate_provider/
    ├── lslidar_driver/
    └── 其他功能包/
```

不要再套一层新的 `ros2_ws/src`。

如果旧 `simple_pid_controller` 仍在 `src` 中，按照迁移计划先把它移动到工作空间外
备份，不要删除。执行前先确认备份目标不存在：

```bash
ls -ld /home/ljz/ros2_ws/src/simple_pid_controller
ls -ld /home/ljz/simple_pid_controller_v2_backup
mv /home/ljz/ros2_ws/src/simple_pid_controller /home/ljz/simple_pid_controller_v2_backup
```

第二条命令如果显示备份目录已经存在，请先人工确认内容并换一个新备份名称，不能
直接覆盖。

若压缩包位于下载目录，可执行：

```bash
unzip ~/Downloads/position_pid_controller.zip -d /home/ljz/ros2_ws/src/
```

## 六、构建

```bash
cd /home/ljz/ros2_ws
source /opt/ros/jazzy/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install --packages-select position_pid_controller
source /home/ljz/ros2_ws/install/setup.bash
```

成功时应看到类似：

```text
Summary: 1 package finished
```

## 七、启动顺序

先启动雷达和 SLAM，确认存在 `map -> base_link` TF；再启动坐标获取包：

```bash
source /home/ljz/ros2_ws/install/setup.bash
ros2 launch map_coordinate_provider coordinate.launch.py
```

确认位姿与有效标志持续更新：

```bash
ros2 topic echo /map/current_pose
ros2 topic echo /map/current_pose_valid
```

然后在另一个终端启动本包：

```bash
source /home/ljz/ros2_ws/install/setup.bash
ros2 launch position_pid_controller position_pid.launch.py
```

也可以临时使用另一份参数文件：

```bash
ros2 launch position_pid_controller position_pid.launch.py \
  params_file:=/home/ljz/my_position_pid_params.yaml
```

## 八、运行时发送新目标

下面示例发送地图坐标 `(x=2 m, y=1 m, yaw=0 rad)`。yaw 为 0 时四元数的
`z=0、w=1`：

```bash
ros2 topic pub --once /pid/target_pose geometry_msgs/msg/PoseStamped \
"{header: {frame_id: 'map'}, pose: {position: {x: 2.0, y: 1.0, z: 0.0}, orientation: {x: 0.0, y: 0.0, z: 0.0, w: 1.0}}}"
```

发送新目标后，x/y/yaw 的积分、微分历史和保持状态都会重置。任意 yaw 对应的平面
四元数可按以下方式换算：

```text
orientation.z = sin(target_yaw / 2)
orientation.w = cos(target_yaw / 2)
orientation.x = 0
orientation.y = 0
```

## 九、查看控制结果

```bash
ros2 topic echo /pid/cmd_vel
ros2 topic echo /pid/control_valid
ros2 topic echo /pid/target_reached
```

正常输出示例：

```yaml
header:
  frame_id: map
twist:
  linear:
    x: 0.30
    y: 0.10
  angular:
    z: -0.12
```

以下任一情况出现时，节点会按控制频率持续发布零速度，并发布
`/pid/control_valid=false`：

- 尚未收到当前位姿或有效标志；
- `current_pose_valid=false` 或该标志超时；
- 当前位姿时间戳超时、来自未来或时钟回退；
- 当前位姿 frame 错误；
- x/y 含 NaN/Inf，或姿态四元数非法；
- 控制循环计时异常。

无效状态不会使用最后一次非零速度。数据恢复后，控制器从已清空的 PID 状态重新
开始计算。

## 十、运行单元测试

```bash
cd /home/ljz/ros2_ws
source /opt/ros/jazzy/setup.bash
colcon test --packages-select position_pid_controller
colcon test-result --verbose
```

测试覆盖 PID 比例/积分/微分、积分与输出限幅、微分滤波、状态重置、平面最小速度、
零 PID 输出时的目标方向回退、平面最大模长、yaw 最小/最大速度、跨越 `±pi` 的最短
误差和迟滞保持。集成测试还会启动真实节点，验证 YAML 加载、目标 topic 覆盖、错误
frame、非法四元数、`valid=false`、数据超时和无效状态下持续发布零速度。

## 十一、真机前必须确认

- `map` 坐标系的 x/y 正方向与飞控执行层理解完全一致；
- 飞控执行层能正确处理“地图系速度”，必要时变换为机体系速度；
- `/pid/control_valid=false` 时执行层立即采用零速度或安全模式；
- 启动、解锁、降落、失联、急停和速度/加速度二次限制已经实现；
- 分别在固定架、低风险场地和较低速度下重新标定三轴参数；
- 本包没有 z 高度控制，不能单独构成完整飞行控制系统。
